<template>
  <div class="card mx-auto mt-5" style="max-width: 500px;">
    <form @submit.prevent="procesarFormulario" class="card-body">
      <h2 class="mb-4">{{ empleado ? 'Editar' : 'Agregar' }} Empleado</h2>

      <input
        class="form-control mb-2"
        type="text"
        v-model.trim="formData.name"
        placeholder="Nombre"
        required
      />

      <input
        class="form-control mb-2"
        type="text"
        v-model.trim="formData.position"
        placeholder="Cargo"
        required
      />

      <input
        class="form-control mb-2"
        type="text"
        v-model.trim="formData.department"
        placeholder="Departamento"
        required
      />

      <input
        class="form-control mb-2"
        type="number"
        v-model.number="formData.salary"
        placeholder="Salario en pesos"
        min="0"
        required
      />

      <input
        class="form-control mb-3"
        type="date"
        v-model="formData.hiringDate"
        required
      />

      <div class="form-check form-switch mb-3">
        <input
          class="form-check-input"
          type="checkbox"
          id="activoSwitch"
          v-model="formData.isActive"
        />
        <label class="form-check-label" for="activoSwitch">
          Activo
        </label>
      </div>

      <button :disabled="cargando" class="btn btn-primary w-100">
        {{ cargando ? 'Guardando...' : 'Guardar' }}
      </button>
    </form>
  </div>
</template>

<script setup lang="ts">
import { ref, reactive, computed, watch } from 'vue'
import { useRouter } from 'vue-router'
import { API } from '@/contantes'
import type { IEmployee } from '@/contantes'

const props = defineProps<{
  empleado: IEmployee | null
}>()

const formData = reactive({
  name: '',
  position: '',
  department: '',
  salary: 0,
  hiringDate: '',
  isActive: true
})

const cargando = ref(false)
const router = useRouter()
const empleado = computed(() => props.empleado)

watch(empleado, () => {
  if (empleado.value) {
    formData.name = empleado.value.name
    formData.position = empleado.value.position
    formData.department = empleado.value.department
    formData.salary = empleado.value.salary
    formData.hiringDate = empleado.value.hiringDate.slice(0, 10) 
    formData.isActive = empleado.value.isActive
  }
}, { immediate: true })

const procesarFormulario = async () => {
  if (cargando.value) return

  try {
    cargando.value = true

    const method = empleado.value ? 'PUT' : 'POST'
    const url = empleado.value ? `${API}/${empleado.value.id}` : API

    const body = JSON.stringify({
      ...formData,
      hiringDate: new Date(formData.hiringDate).toISOString()
    })

    const response = await fetch(url, {
      method,
      headers: {
        'Content-Type': 'application/json'
      },
      body
    })

    if (!response.ok) {
      const errorText = await response.text()
      throw new Error(`Error ${response.status}: ${errorText}`)
    }

    alert(`Empleado ${empleado.value ? 'actualizado' : 'creado'} con éxito`)
    router.back()
  } catch (error: any) {
    console.error('Error al procesar formulario:', error)
    alert(`Error al guardar el empleado: ${error.message || 'Desconocido'}`)
  } finally {
    cargando.value = false
  }
}
</script>
