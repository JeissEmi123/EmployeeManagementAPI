<template>
  <div class="card shadow-md rounded-lg p-6 bg-white">
    <div class="mb-4">
      <input
        v-model="search"
        type="text"
        placeholder="🔍 Buscar por nombre, cargo, departamento, ID..."
        class="w-full p-2 border rounded-md focus:outline-none focus:ring focus:border-blue-300"
      />
    </div>

    <!-- ⏳ Cargando -->
    <div v-if="loading" class="text-center text-gray-500 py-6">
      ⏳ Cargando empleados...
    </div>

    <!-- 📋 Tabla de empleados -->
    <table v-else class="table-auto w-full border-collapse">
      <thead class="bg-gray-100 text-left">
        <tr>
          <th class="px-4 py-2">👤 Nombre</th>
          <th class="px-4 py-2">👔 Cargo</th>
          <th class="px-4 py-2">🏢 Departamento</th>
          <th class="px-4 py-2">💰 Salario</th>
          <th class="px-4 py-2">📅 Contratación</th>
          <th class="px-4 py-2">📌 Estado</th>
          <th class="px-4 py-2">⚙️ Acciones</th>
        </tr>
      </thead>
      <tbody>
        <tr
          v-for="empleado in empleadosFiltrados"
          :key="empleado.id"
          class="border-t hover:bg-gray-50 transition cursor-pointer"
        >
          <td
            class="px-4 py-2 text-blue-600 hover:underline"
            @click="editar(empleado.id)"
          >
            {{ empleado.name }}
          </td>
          <td class="px-4 py-2">{{ empleado.position }}</td>
          <td class="px-4 py-2">{{ empleado.department }}</td>
          <td class="px-4 py-2">{{ formatCurrency(empleado.salary) }}</td>
          <td class="px-4 py-2">{{ formatDate(empleado.hiringDate) }}</td>
          <td class="px-4 py-2">
            <span :class="empleado.isActive ? 'text-green-600' : 'text-gray-500'">
              {{ empleado.isActive ? '🟢 Activo' : '⚪ Inactivo' }}
            </span>
          </td>
          <td class="px-4 py-2 space-x-2">
            <button
              @click.stop="editar(empleado.id)"
              class="text-blue-600 hover:underline"
              title="Editar"
              aria-label="Editar empleado"
            >
              ✏️ Editar
            </button>
            <button
              @click.stop="desactivar(empleado)"
              class="text-red-600 hover:underline"
              title="Desactivar"
              :disabled="!empleado.isActive"
              aria-label="Desactivar empleado"
            >
              ❌ Desactivar
            </button>
          </td>
        </tr>
      </tbody>
    </table>

    <!-- ❗ Sin resultados -->
    <div v-if="!empleadosFiltrados.length && !loading" class="text-center text-gray-400 py-4">
      🚫 No se encontraron empleados.
    </div>

    <!-- Notificación de error -->
    <div v-if="errorMessage" class="mt-4 text-center text-red-500">
      ⚠️ {{ errorMessage }}
    </div>
  </div>
</template>

<script setup lang="ts">
import { ref, onMounted, computed } from 'vue';
import { useRouter } from 'vue-router';
import axios from 'axios'; // Usamos axios en vez de fetch
import { API } from '@/contantes';
import type { IEmployee } from '@/contantes';

const empleados = ref<IEmployee[]>([]);
const loading = ref(true);
const search = ref('');
const errorMessage = ref<string | null>(null); // Para manejar mensajes de error
const router = useRouter();

// Computed para filtrar empleados basado en la búsqueda (nombre, cargo, departamento, ID)
const empleadosFiltrados = computed(() => {
  if (!empleados.value || empleados.value.length === 0) return [];
  const searchLower = search.value.toLowerCase();
  return empleados.value.filter(e =>
    e.name.toLowerCase().includes(searchLower) ||
    e.position.toLowerCase().includes(searchLower) ||
    e.department.toLowerCase().includes(searchLower) ||
    e.id.toString().includes(searchLower) // Filtra también por ID
  );
});

// Redirige a la página de edición de empleado y obtiene los detalles
const editar = async (id: string) => {
  try {
    // Hacer una solicitud GET para obtener los detalles del empleado
    const response = await axios.get(`${API}/${id}`);
    const empleado = response.data;
    // Redirigir a la página de edición con los detalles del empleado
    router.push({ name: 'editar', params: { id: empleado.id } });
  } catch (error) {
    console.error(error);
    errorMessage.value = '⚠️ Error al obtener los detalles del empleado.';
  }
};

// Función para desactivar el empleado
const desactivar = async (empleado: IEmployee) => {
  if (confirm(`¿Estás seguro de desactivar al empleado ${empleado.name}?`)) {
    try {
      // Realizamos la solicitud para desactivar el empleado usando DELETE
      const response = await axios.delete(`${API}/${empleado.id}`);
      if (response.status === 200) {
        alert('Empleado desactivado con éxito');
        empleados.value = empleados.value.map(e => e.id === empleado.id ? { ...e, isActive: false } : e); // Actualiza el estado local del empleado
      } else {
        throw new Error('Error al desactivar el empleado');
      }
    } catch (error) {
      console.error(error);
      errorMessage.value = '⚠️ Error al desactivar el empleado.';
    }
  }
};

// Carga los empleados cuando el componente se monta
onMounted(async () => {
  try {
    const response = await axios.get(API);
    empleados.value = response.data;
  } catch (error) {
    console.error(error);
    errorMessage.value = '⚠️ Hubo un problema al cargar los empleados.';
  } finally {
    loading.value = false;
  }
});

// Función para formatear la moneda en pesos colombianos
const formatCurrency = (value: number) => {
  return new Intl.NumberFormat('es-CO', {
    style: 'currency',
    currency: 'COP',
    minimumFractionDigits: 0,
  }).format(value);
};

// Función para formatear la fecha
const formatDate = (isoDate: string) => {
  return new Date(isoDate).toLocaleDateString('es-CO', {
    year: 'numeric',
    month: 'short',
    day: '2-digit',
  });
};
</script>

<style scoped>
/* Estilos opcionales */
button:disabled {
  cursor: not-allowed;
  opacity: 0.5;
}
</style>
