export const API = 'https://localhost:44317/api/employees';

export interface IEmployee {
  id: string;
  name: string;
  position: string;
  department: string;
  salary: number;
  hiringDate: string; // formato ISO: yyyy-MM-ddTHH:mm:ss
  isActive: boolean;
}
