import { createRouter, createWebHistory } from 'vue-router';
import HomeView from '../views/HomeView.vue';

const router = createRouter({
  history: createWebHistory(import.meta.env.BASE_URL),
  routes: [
    {
      path: '/',
      name: 'home',
      component: HomeView,
    },
    {
      path: '/tareas',
      name: 'tareas',
      component: () => import('../views/EmployeesAdd.vue'), // Carga perezosa para el componente de agregar empleados
    },
    {
      path: '/tarea-formulario/:id?',
      name: 'tarea-formulario',
      component: () => import('../views/EmployeeFormularioView.vue'), // Carga perezosa para el formulario de empleado
      props: true, // Permite pasar el parámetro `id` como prop
    },
    {
      path: '/editar/:id',
      name: 'editar',
      component: () => import('../views/EditEmployee.vue'), // Carga perezosa para editar empleado
      props: true, // Permite pasar el parámetro `id` como prop
    },
    {
      path: '/desactivar-empleado/:id',
      name: 'desactivar-empleado', // Asignamos un nombre a la ruta
      component: () => import('../views/DesEmployees.vue'),
      props: true, // Permite pasar el parámetro `id` como prop
    },
  ],
});

export default router;
