<template>
  <div class="card mx-auto mt-5" style="max-width: 500px;">
    <form @submit.prevent="procesarFormulario" class="card-body">
      <h2 class="mb-4">Desactivar Empleado</h2>

      <input
        class="form-control mb-2"
        type="text"
        v-model.trim="formData.name"
        placeholder="Nombre"
        disabled
      />

      <input
        class="form-control mb-2"
        type="text"
        v-model.trim="formData.position"
        placeholder="Cargo"
        disabled
      />

      <input
        class="form-control mb-2"
        type="text"
        v-model.trim="formData.department"
        placeholder="Departamento"
        disabled
      />

      <input
        class="form-control mb-3"
        type="number"
        v-model.number="formData.salary"
        placeholder="Salario en pesos"
        min="0"
        disabled
      />

      <input
        class="form-control mb-3"
        type="date"
        v-model="formData.hiringDate"
        disabled
      />

      <div class="form-check form-switch mb-3">
        <input
          class="form-check-input"
          type="checkbox"
          id="activoSwitch"
          v-model="formData.isActive"
          :disabled="true" <!-- Deshabilitado para que no se pueda modificar -->
        />
        <label class="form-check-label" for="activoSwitch">
          Activo
        </label>
      </div>

      <button :disabled="cargando" class="btn btn-danger w-100">
        {{ cargando ? 'Desactivando...' : 'Desactivar' }}
      </button>
    </form>
  </div>
</template>

<script setup lang="ts">
import { ref, reactive, onMounted } from 'vue';
import { useRouter, useRoute } from 'vue-router';
import axios from 'axios'; 
import { API } from '@/contantes';

const router = useRouter();
const route = useRoute();


const empleadoId = route.params.id as string;

const formData = reactive({
  name: '',
  position: '',
  department: '',
  salary: 0,
  hiringDate: '',
  isActive: true
});

const cargando = ref(false);

onMounted(async () => {
  try {
    const response = await axios.get(`${API}/employees/${empleadoId}`);
    formData.name = response.data.name;
    formData.position = response.data.position;
    formData.department = response.data.department;
    formData.salary = response.data.salary;
    formData.hiringDate = response.data.hiringDate.slice(0, 10); 
    formData.isActive = response.data.isActive;
  } catch (error) {
    console.error('Error al cargar el empleado:', error);
    alert('Error al cargar la información del empleado.');
  }
});

const procesarFormulario = async () => {
  if (cargando.value) return;

  try {
    cargando.value = true;

    const url = `${API}/employees/${empleadoId}`; 

    const response = await axios.patch(url, {
      isActive: false
    });

    if (response.status !== 200) {
    
      throw new Error(`Error al desactivar el empleado: ${response.statusText}`);
    }

    
    alert('Empleado desactivado con éxito');
    router.push('/'); 
  } catch (error: any) {
    console.error('Error al procesar formulario:', error);
    alert(`Error al desactivar el empleado: ${error.message || 'Desconocido'}`);
  } finally {
    cargando.value = false;
  }
};
</script>

<style scoped>
button:disabled {
  cursor: not-allowed;
  opacity: 0.6;
}
</style>
