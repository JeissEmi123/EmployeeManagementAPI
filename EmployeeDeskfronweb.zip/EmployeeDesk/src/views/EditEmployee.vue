<template>
  <div class="card mx-auto mt-5" style="max-width: 500px;">
    <form @submit.prevent="procesarFormulario" class="card-body">
      <h2 class="mb-4">Editar Empleado</h2>

      <input
        class="form-control mb-2"
        type="text"
        v-model.trim="formData.name"
        placeholder="Nombre"
        required
      />

      <input
        class="form-control mb-2"
        type="text"
        v-model.trim="formData.position"
        placeholder="Cargo"
        required
      />

      <input
        class="form-control mb-2"
        type="text"
        v-model.trim="formData.department"
        placeholder="Departamento"
        required
      />

      <input
        class="form-control mb-2"
        type="number"
        v-model.number="formData.salary"
        placeholder="Salario en pesos"
        min="0"
        required
      />

      <input
        class="form-control mb-3"
        type="date"
        v-model="formData.hiringDate"
        required
      />

      <div class="form-check form-switch mb-3">
        <input
          class="form-check-input"
          type="checkbox"
          id="activoSwitch"
          v-model="formData.isActive"
        />
        <label class="form-check-label" for="activoSwitch">
          Activo
        </label>
      </div>

      <button :disabled="cargando" class="btn btn-primary w-100">
        {{ cargando ? 'Guardando...' : 'Guardar' }}
      </button>
    </form>
  </div>
</template>

<script setup lang="ts">
import { ref, reactive, computed, watch, onMounted } from 'vue';
import { useRouter, useRoute } from 'vue-router';
import { API } from '@/contantes'; // Asegúrate de que tu constante API esté bien configurada
import type { IEmployee } from '@/contantes';

const props = defineProps<{
  empleado: IEmployee | null;
}>();

const formData = reactive({
  name: '',
  position: '',
  department: '',
  salary: 0,
  hiringDate: '',
  isActive: true
});

const cargando = ref(false);
const router = useRouter();
const route = useRoute();
const empleadoId = route.params.id as string;

const empleado = computed(() => props.empleado);

// Si no se pasa el empleado como prop, intentar cargarlo desde la API
onMounted(async () => {
  if (!empleado.value) {
    try {
      const response = await fetch(`${API}/${empleadoId}`);
      if (!response.ok) throw new Error('Empleado no encontrado');

      const data = await response.json();
      formData.name = data.name;
      formData.position = data.position;
      formData.department = data.department;
      formData.salary = data.salary;
      formData.hiringDate = data.hiringDate.slice(0, 10); // Formatear la fecha
      formData.isActive = data.isActive;
    } catch (error) {
      console.error('Error al cargar el empleado:', error);
      alert('Error al cargar la información del empleado.');
    }
  }
});

const procesarFormulario = async () => {
  if (cargando.value) return;

  try {
    cargando.value = true;

    const url = `${API}/${empleadoId}`; // Actualizar el empleado con el ID correspondiente

    const body = JSON.stringify({
      ...formData,
      hiringDate: new Date(formData.hiringDate).toISOString()
    });

    const response = await fetch(url, {
      method: 'PUT', // Solo actualización (PUT)
      headers: {
        'Content-Type': 'application/json'
      },
      body
    });

    if (!response.ok) {
      const errorText = await response.text();
      throw new Error(`Error ${response.status}: ${errorText}`);
    }

    alert('Empleado actualizado con éxito');
    router.back();
  } catch (error: any) {
    console.error('Error al procesar formulario:', error);
    alert(`Error al guardar el empleado: ${error.message || 'Desconocido'}`);
  } finally {
    cargando.value = false;
  }
};
</script>

<style scoped>
/* Estilos opcionales para error y éxito */
.error-message {
  background-color: #fdd5d5;
  color: #e53e3e;
  border: 1px solid #e53e3e;
  border-radius: 0.375rem;
}

.success-message {
  background-color: #c6f6d5;
  color: #38a169;
  border: 1px solid #38a169;
  border-radius: 0.375rem;
}

button:disabled {
  cursor: not-allowed;
  opacity: 0.6;
}
</style>
