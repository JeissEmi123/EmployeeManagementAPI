<template>
  <div>
    <h1>Lista de Empleados</h1>
    <ul>
      <li v-for="empleado in empleados" :key="empleado.id">
        {{ empleado.name }}
      </li>
    </ul>
  </div>
</template>

<script setup>
import { ref, onMounted } from 'vue';

const empleados = ref([]);

onMounted(async () => {
  try {
    const response = await fetch('/api/employees');
    if (!response.ok) throw new Error('Error al obtener los empleados');
    empleados.value = await response.json();
  } catch (error) {
    console.error(error);
    alert('Error al cargar la lista de empleados');
  }
});
</script>
