<script setup lang="ts">
import { ref } from 'vue'

const showFormulario = ref(false)
const EmployeeFormularioView = ref<any>(null)

const cargarFormulario = async (type: string) => {
  let modulo;
  if (type === 'crear') {
    modulo = await import('../views/EmployeeFormularioView.vue');
  } else if (type === 'editar') {
    modulo = await import('../views/EditEmployee.vue');
    
  }
  if (!modulo) {
    console.error("No se pudo cargar el módulo.");
    return;
  }

  EmployeeFormularioView.value = modulo.default;
  showFormulario.value = true;
}
const cerrarFormulario = () => {
  showFormulario.value = false
}
</script>

<template>
  <main class="home-wrapper">
    <section class="welcome-section">
      <h1 class="title">Sistema de Empleados</h1>
      <p class="subtitle">Gestionar colaborador</p>

      <div class="features">
        <div class="feature-item link-card" @click="cargarFormulario('crear')">
          <span class="icon">📝</span>
          <div>
            <h3>Crear empleado</h3>
            <p>Agrega nuevo empleado.</p>
          </div>
        </div>

        <div class="feature-item link-card">
          <span class="icon">🔄</span>
          <div>
            <RouterLink  exact-active-class="activo" to="/tareas"><h3>Editar empleado</h3></RouterLink>
        
            <p>Actualiza información empleado</p>
          </div>
        </div>

    
      </div>
    </section>

    <!-- MODAL -->
    <div v-if="showFormulario" class="modal-overlay" @click.self="cerrarFormulario">
      <div class="modal-content">
        <component
          :is="EmployeeFormularioView"
          @cerrar="cerrarFormulario"
        />
      </div>
    </div>
  </main>
</template>

<style scoped>
.home-wrapper {
  padding: 4rem 1rem;
  background-color: #f4f6f8;
  display: flex;
  justify-content: center;
}
.welcome-section {
  background-color: #fff;
  padding: 3rem 2rem;
  border-radius: 1rem;
  box-shadow: 0 4px 12px rgba(0, 0, 0, 0.06);
  max-width: 800px;
  width: 100%;
}
.title {
  font-size: 2rem;
  color: #333;
  margin-bottom: 1rem;
  text-align: center;
}
.subtitle {
  font-size: 1.1rem;
  color: #666;
  text-align: center;
  margin-bottom: 2rem;
}
.features {
  display: flex;
  flex-direction: column;
  gap: 1.5rem;
  margin-bottom: 2rem;
}
.feature-item {
  display: flex;
  align-items: flex-start;
  gap: 1rem;
  text-decoration: none;
  color: inherit;
}
.icon {
  font-size: 2rem;
}
.feature-item h3 {
  margin: 0;
  font-size: 1.2rem;
  color: #222;
}
.feature-item p {
  margin: 0.25rem 0 0;
  color: #555;
  font-size: 0.95rem;
}
.link-card {
  transition: all 0.2s ease-in-out;
  padding: 1rem;
  border-radius: 0.75rem;
  cursor: pointer;
}
.link-card:hover {
  background-color: #f0f0f0;
  transform: translateY(-2px);
}
.link-card:active {
  transform: scale(0.98);
}

/* MODAL STYLES */
.modal-overlay {
  position: fixed;
  top: 0;
  left: 0;
  width: 100%;
  height: 100%;
  background: rgba(0, 0, 0, 0.5);
  display: flex;
  justify-content: center;
  align-items: center;
  z-index: 999;
}
.modal-content {
  background: #fff;
  padding: 2rem;
  border-radius: 1rem;
  max-width: 600px;
  width: 90%;
  max-height: 90vh;
  overflow-y: auto;
  box-shadow: 0 10px 30px rgba(0, 0, 0, 0.3);
  animation: slideUp 0.3s ease-out;
}
@keyframes slideUp {
  from {
    transform: translateY(30px);
    opacity: 0;
  }
  to {
    transform: translateY(0);
    opacity: 1;
  }
}
</style>
